# The Art Garden — Netlify-ready site

Ready-to-deploy static site with editable events.

Contact links:
- Phone: +1 (868) 290-4271
- Email: theartgardentt@gmail.com
- WhatsApp: https://wa.me/18682904271

Social placeholders in `index.html`:
- Instagram: https://instagram.com/REPLACE_WITH_HANDLE
- Facebook: https://facebook.com/REPLACE_WITH_PAGE
- TikTok: https://tiktok.com/@REPLACE_WITH_HANDLE

Event content is stored in `events.json` and can be edited through Decap CMS at `/admin/` once Git Gateway/Identity is enabled in Netlify.

The two registration links currently point to `https://theart.garden/` as placeholders until the real registration URLs are supplied.
